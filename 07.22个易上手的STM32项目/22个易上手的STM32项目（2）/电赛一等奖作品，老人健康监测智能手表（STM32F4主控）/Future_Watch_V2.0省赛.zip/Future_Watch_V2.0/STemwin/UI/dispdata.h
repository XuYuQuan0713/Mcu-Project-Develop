#ifndef _DISPDATA_H_
#define _DISPDATA_H_

#include "DIALOG.h"

WM_HWIN Create_DataWindow(void);

#endif

