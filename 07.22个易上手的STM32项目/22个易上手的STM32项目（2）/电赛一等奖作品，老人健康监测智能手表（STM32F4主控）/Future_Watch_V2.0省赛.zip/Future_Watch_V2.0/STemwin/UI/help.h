#ifndef _HELP_H_
#define _HELP_H_

#include <stdlib.h>
#include "GUI.h"
#include "DIALOG.h"

WM_HWIN Create_HelpWindow(void);
#endif
