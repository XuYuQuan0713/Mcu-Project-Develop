#ifndef _DISPWIFI_H_
#define _DISPWIFI_H_

#include "DIALOG.h"
#include "sys.h"
#include "delay.h"
#include "WM.h"

WM_HWIN Create_WifiWindow(void);

#endif
