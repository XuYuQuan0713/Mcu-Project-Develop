#ifndef __TIMER_4_H
#define __TIMER_4_H
#include "sys.h"
	  

void Time_4_Init(u16 arr,u16 psc);
#endif























