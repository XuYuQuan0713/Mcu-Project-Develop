package com.karics.library.zxing.android;

public enum IntentSource {

  NATIVE_APP_INTENT,
  PRODUCT_SEARCH_LINK,
  ZXING_LINK,
  NONE

}
